env env_var1=no ENV_VAR1=test123 $TEST_PROG
