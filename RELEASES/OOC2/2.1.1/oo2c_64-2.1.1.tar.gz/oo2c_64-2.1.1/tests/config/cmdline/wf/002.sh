$TEST_PROG foo bar test123 1.2 /not_there
