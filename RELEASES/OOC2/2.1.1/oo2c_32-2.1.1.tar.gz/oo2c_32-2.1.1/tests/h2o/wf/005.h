/* Test self definition */
#define foo foo
begin
foo
end
