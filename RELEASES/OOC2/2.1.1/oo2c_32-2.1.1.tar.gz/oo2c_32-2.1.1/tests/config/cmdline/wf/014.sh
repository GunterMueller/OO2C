$TEST_PROG -a '<' three '>' '&' "'" -o '"<>&'
