env DEFAULT_CFG_FILE="" $TEST_PROG --set-a "value from command line" foo bar 123
