env DEFAULT_CFG_FILE="wf/cfg/009.xml" CONFIG_FILE="wf/cfg/009-env.xml" $TEST_PROG foo
