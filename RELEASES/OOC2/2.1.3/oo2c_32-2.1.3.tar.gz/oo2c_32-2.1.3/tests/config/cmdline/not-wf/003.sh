$TEST_PROG --no_such_option
