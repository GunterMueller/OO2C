<?xml version='1.0' encoding='ISO-8859-1' standalone='yes'?>
<configuration>
<options><set name='env_var1_lc'>no</set></options>
<options><set foo='this is also evaluated!'/></options>
</configuration>
