/* Test substitution with parameters */
#define add(x,y) (x+y)
begin
add(1,1)
end
