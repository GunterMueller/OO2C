env env_var1=no $TEST_PROG
