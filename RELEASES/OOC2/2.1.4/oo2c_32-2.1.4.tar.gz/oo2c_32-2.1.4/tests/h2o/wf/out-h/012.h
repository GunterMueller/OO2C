0
1
2
else
