/* Test blank definition */
#define bar
begin
bar
end
