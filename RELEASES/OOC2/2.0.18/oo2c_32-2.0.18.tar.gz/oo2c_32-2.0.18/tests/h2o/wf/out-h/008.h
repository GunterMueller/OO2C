/* Test redefinition */
begin
1
2
foo

end
