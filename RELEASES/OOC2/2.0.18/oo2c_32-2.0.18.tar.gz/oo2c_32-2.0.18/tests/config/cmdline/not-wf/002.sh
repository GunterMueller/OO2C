$TEST_PROG three 1 2
