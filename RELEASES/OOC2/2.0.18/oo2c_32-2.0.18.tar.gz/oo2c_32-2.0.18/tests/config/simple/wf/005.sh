env DEFAULT_CFG_FILE="" TEST_A="value from environment" $TEST_PROG foo bar 123
