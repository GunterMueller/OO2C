<?xml version='1.0' encoding='ISO-8859-1' standalone='yes'?>
<configuration>
<options><set name='one_argument_option'>arg</set></options>
<options><set name='three_argument_option'a1='1' a2='2' a3='3'/></options>
<options><set name='flag_one'>TRUE</set></options>
<arguments>
  <arg>4</arg>
</arguments>
</configuration>
