$TEST_PROG -1 --flag-two --flag-one "foo bar"
