<?xml version='1.0' encoding='ISO-8859-1' standalone='yes'?>
<configuration>
<options><set name='one_argument_option'>&lt;&gt;&amp;</set></options>
<options><set name='one_argument_option'>&apos;</set></options>
<options><set name='one_argument_option'>&quot;</set></options>
<arguments>
</arguments>
</configuration>
