$TEST_PROG -a arg three 1 2 3 -o 4
