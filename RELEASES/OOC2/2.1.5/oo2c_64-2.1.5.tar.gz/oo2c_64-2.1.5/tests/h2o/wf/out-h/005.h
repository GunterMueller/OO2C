/* Test self definition */
begin
foo
end
