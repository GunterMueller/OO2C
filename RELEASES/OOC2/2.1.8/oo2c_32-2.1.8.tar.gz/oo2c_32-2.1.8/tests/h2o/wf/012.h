#define A 0
#if A==0
0
#elif A==1
1
#elif A==2
2
#else
else
#endif
#undef A
#define A 1
#if A==0
0
#elif A==1
1
#elif A==2
2
#else
else
#endif
#undef A
#define A 2
#if A==0
0
#elif A==1
1
#elif A==2
2
#else
else
#endif
#undef A
#define A 3
#if A==0
0
#elif A==1
1
#elif A==2
2
#else
else
#endif
