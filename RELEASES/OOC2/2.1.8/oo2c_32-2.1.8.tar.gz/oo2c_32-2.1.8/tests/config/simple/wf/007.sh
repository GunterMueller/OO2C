env DEFAULT_CFG_FILE="wf/cfg/007.xml" TEST_A="environment supersedes config file" $TEST_PROG foo bar 123
