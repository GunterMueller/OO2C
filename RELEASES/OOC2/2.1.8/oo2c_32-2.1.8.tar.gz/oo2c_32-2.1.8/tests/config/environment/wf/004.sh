env env_var1=yes $TEST_PROG
