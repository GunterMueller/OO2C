<?xml version='1.0' encoding='ISO-8859-1' standalone='yes'?>
<configuration>
<options><set name='flag_one'>TRUE</set></options>
<options><set name='flag_one'>TRUE</set></options>
<options><set name='o2'/></options>
<arguments>
</arguments>
</configuration>
