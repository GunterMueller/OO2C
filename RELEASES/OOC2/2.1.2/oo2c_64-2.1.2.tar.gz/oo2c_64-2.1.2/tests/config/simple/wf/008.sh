env DEFAULT_CFG_FILE="wf/cfg/008.xml" TEST_A="environment" $TEST_PROG --set-a "command line supersedes environment" foo bar 123
