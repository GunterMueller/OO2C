env DISABLE_DASH_DASH=yes $TEST_PROG -- foo bar
