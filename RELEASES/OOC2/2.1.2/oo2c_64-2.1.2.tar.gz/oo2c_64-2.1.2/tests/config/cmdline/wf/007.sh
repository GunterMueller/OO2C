$TEST_PROG --flag-one "foo bar"
