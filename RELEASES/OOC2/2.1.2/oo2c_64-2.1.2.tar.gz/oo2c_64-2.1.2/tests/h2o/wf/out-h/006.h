/* Test blank definition */
begin

end
