/* Test substitution with parameters */
begin
(1+1)
end
