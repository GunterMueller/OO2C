<?xml version='1.0' encoding='ISO-8859-1' standalone='yes'?>
<configuration>
<arguments>
  <arg>tab	space </arg>
</arguments>
</configuration>
