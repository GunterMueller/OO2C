env DEFAULT_CFG_FILE="wf/cfg/003.xml" $TEST_PROG foo bar 123
