/* Test simple macro substitution */
begin
1
1
end
