/* Test all symbols for the C language */

ident 123 "string"
/* delimited comment */
// one-line comment

, ( ) {  } [ ] : ; . ? ... 
+ - * / % << >> && || !
= += -= *= /= %= <<= >>= &= |= ^=
== > < >= <= !=
& | ~ ^

extern typedef static
float double int char
wchar int64
long short signed unsigned
struct union void enum
cdecl stdcall
const volatile
sizeof
