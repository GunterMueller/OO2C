$TEST_PROG -1 -- foo
