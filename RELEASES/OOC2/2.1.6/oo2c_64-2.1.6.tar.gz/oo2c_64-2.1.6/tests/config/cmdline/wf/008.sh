$TEST_PROG --flag-two foo\ bar
