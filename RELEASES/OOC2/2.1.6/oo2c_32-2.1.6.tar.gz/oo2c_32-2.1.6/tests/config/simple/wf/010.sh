env DEFAULT_CFG_FILE="wf/cfg/010.xml" CONFIG_FILE="wf/cfg/010-env.xml" $TEST_PROG --config wf/cfg/010-opt.xml foo
