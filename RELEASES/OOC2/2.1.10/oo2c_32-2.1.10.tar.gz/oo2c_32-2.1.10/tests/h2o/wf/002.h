/* Test simple macro substitution */
#define one 1
begin
one
one
end
