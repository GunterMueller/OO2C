typedef int T;
typedef int * pT;
