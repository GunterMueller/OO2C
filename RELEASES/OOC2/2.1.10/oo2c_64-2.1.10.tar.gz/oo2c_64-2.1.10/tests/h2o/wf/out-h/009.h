/* Test conditional macros */
1
yes
0
yes
