/* Test #if and expression evaluation */
#if 0
0
#else
1
#endif
#if 1
1
#else
0
#endif
