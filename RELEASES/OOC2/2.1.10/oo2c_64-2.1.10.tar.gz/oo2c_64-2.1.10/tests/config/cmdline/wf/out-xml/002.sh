<?xml version='1.0' encoding='ISO-8859-1' standalone='yes'?>
<configuration>
<arguments>
  <arg>foo</arg>
  <arg>bar</arg>
  <arg>test123</arg>
  <arg>1.2</arg>
  <arg>/not_there</arg>
</arguments>
</configuration>
