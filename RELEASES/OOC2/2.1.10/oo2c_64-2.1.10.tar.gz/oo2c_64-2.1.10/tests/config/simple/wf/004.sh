env DEFAULT_CFG_FILE="wf/cfg/004.xml" $TEST_PROG foo bar 123
