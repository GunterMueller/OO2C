/* Test undefinition */
begin
1
foo
end
