<?xml version='1.0' encoding='ISO-8859-1' standalone='yes'?>
<configuration>
<options><set name='one_argument_option'>&lt;</set></options>
<options><set name='three_argument_option'a1='&gt;' a2='&amp;' a3='&apos;'/></options>
<options><set name='flag_one'>TRUE</set></options>
<arguments>
  <arg>&quot;&lt;&gt;&amp;</arg>
</arguments>
</configuration>
