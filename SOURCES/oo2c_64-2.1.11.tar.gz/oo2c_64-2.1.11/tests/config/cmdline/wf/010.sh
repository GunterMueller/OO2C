$TEST_PROG -o "overloaded option?!"
