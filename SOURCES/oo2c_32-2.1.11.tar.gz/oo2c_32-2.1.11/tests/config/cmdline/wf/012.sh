$TEST_PROG three 1 2 3 4
