$TEST_PROG -2 furbie two
