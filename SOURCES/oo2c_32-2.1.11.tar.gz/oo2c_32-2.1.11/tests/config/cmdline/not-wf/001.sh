$TEST_PROG --arg-option
