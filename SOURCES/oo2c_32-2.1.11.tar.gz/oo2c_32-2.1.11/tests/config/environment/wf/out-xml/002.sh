<?xml version='1.0' encoding='ISO-8859-1' standalone='yes'?>
<configuration>
<options><set name='env_var1_uc'>TRUE</set></options>
</configuration>
